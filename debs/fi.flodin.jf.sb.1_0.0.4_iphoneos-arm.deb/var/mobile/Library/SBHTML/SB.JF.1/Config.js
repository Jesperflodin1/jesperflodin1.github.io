var clock_twentyfour = true; // 24h clock or 12h clock
var sundayFirst = false; // Sunday as first day of week?
var Lang = "sv"; // choose between "en", "ca", "fr", "de", "it", "ru", "pl", "pt", "cz", "no", "nl", "fi", "cn", "zh", "sv"
var IconSet = "Custom"; // Weather Icons